# PracticeAssignment05
Starter code (testing class) for P05
